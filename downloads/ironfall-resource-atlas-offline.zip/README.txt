IRONFALL RESOURCE ATLAS — CHUNK-RESOLUTION UPDATE

Extract the ENTIRE offline ZIP. Keep the density-inline folder next to
ironfall-resource-atlas.html, then open the HTML in a modern browser.
No HTTP server or internet connection is required for the offline package.
All code, copied terrain imagery and all 22 resources at every Y band are included.
The detailed layer files load only as needed.

Density is measured in 16x16 block cells, 16 times finer per direction than v1.
Display interpolation smooths neighboring measured cells; tooltip counts stay exact.
Grayscale terrain affects only the background; ore overlays keep their colors.
Hotspot rankings and selected-area summaries cover 256x256 search areas.

The Terracotta iron veins toggle marks 38,090 verified 16-cube sections.
Markers cluster when zoomed out; click to zoom, inspect or export coordinates.
The detection rule is documented in About the survey and can miss small remnants.

All 1,843,200 chunks were rescanned, zero errors. Every fine count was summed
to its original search area and compared across all 22 ores and 24 depth bands:
all values match exactly. Original BlueMap and world save are unchanged.

Live map: https://halfwayhaus.github.io/ironfall-resource-atlas/
